package cp213;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.print.PrinterJob;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * The GUI for the Order class.
 *
 * @author Ashish Sharma
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2023-09-06
 */
@SuppressWarnings("serial")
public class OrderPanel extends JPanel {

    // Attributes
    private Menu menu = null; // Menu attached to panel.
    private final Order order = new Order(); // Order to be printed by panel.
    // GUI Widgets
    private final JButton printButton = new JButton("Print");
    private final JLabel subtotalLabel = new JLabel("0");
    private final JLabel taxLabel = new JLabel("0");
    private final JLabel totalLabel = new JLabel("0");

    private JLabel nameLabels[] = null;
    private JLabel priceLabels[] = null;
    // TextFields for menu item quantities.
    private JTextField quantityFields[] = null;

    /**
     * Displays the menu in a GUI.
     *
     * @param menu The menu to display.
     */
    public OrderPanel(final Menu menu) {
	this.menu = menu;
	this.nameLabels = new JLabel[this.menu.size()];
	this.priceLabels = new JLabel[this.menu.size()];
	this.quantityFields = new JTextField[this.menu.size()];
	this.layoutView();
	this.registerListeners();
    }

    /**
     * Implements an ActionListener for the 'Print' button. Prints the current
     * contents of the Order to a system printer or PDF.
     */
    private class PrintListener implements ActionListener {

	@Override
	public void actionPerformed(final ActionEvent e) {

		// your code here
		final PrinterJob print_job = PrinterJob.getPrinterJob();
		print_job.setPrintable(order);
		if (print_job.printDialog())
			;
		try {
			print_job.print();
		} catch (final Exception printException) {
			System.err.println(printException);
		}

	}
    }

    /**
     * Implements a FocusListener on a JTextField. Accepts only positive integers,
     * all other values are reset to 0. Adds a new MenuItem to the Order with the
     * new quantity, updates an existing MenuItem in the Order with the new
     * quantity, or removes the MenuItem from the Order if the resulting quantity is
     * 0.
     */
    private class QuantityListener implements FocusListener {
	private MenuItem item = null;

	QuantityListener(final MenuItem item) {
	    this.item = item;
	}

	// your code here
	@Override
	public void focusGained(FocusEvent e) {
	    // Implement if needed
	}
	
	@Override
	public void focusLost(FocusEvent e) {
		JTextField source = (JTextField) e.getSource();
		try {
			int quantity = Integer.parseInt(source.getText());
			if (quantity < 0) {
				// Handle invalid input (negative quantity)
				System.out.println("Invalid quantity: " + quantity);
				source.setText("0");
			} else {
				// Update the order with the new quantity
				order.add(item, quantity);
			}
		} catch (NumberFormatException ex) {
			// Handle invalid input (non-integer)
			System.out.println("Invalid quantity: " + source.getText());
			source.setText("0");
		}
	}
	
    }

    /**
     * Layout the panel.
     */
	private void layoutView() {
		// your code here
		this.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
		this.setLayout(new GridLayout(0, 3));
		this.add(new JLabel("Item"));
		this.add(new JLabel("Price"));
		this.add(new JLabel("Quantity"));
		QuantityListener ql;

		for (int i = 0; i < menu.size(); i++) {
			ql = new QuantityListener(menu.getItem(i));
			this.add(new JLabel(menu.getItem(i).getName()));
			this.add(new JLabel(String.format("$%.2f", menu.getItem(i).getPrice())));
			JTextField quantityBox = new JTextField("0");
			this.add(quantityBox);
			quantityBox.addFocusListener(ql);
			quantityFields[i] = quantityBox;
		}
		this.add(new JLabel("Subtotal:"));
		this.add(new JLabel());
		this.add(subtotalLabel);
		this.add(new JLabel("Tax:"));
		this.add(new JLabel());
		this.add(taxLabel);
		this.add(new JLabel("Total:"));
		this.add(new JLabel());
		this.add(totalLabel);
		this.printButton.addActionListener(new PrintListener());
		this.add(this.printButton);
		return;

	}

    /**
     * Register the widget listeners.
     */
	private void registerListeners() {
		// Register the PrinterListener with the print button.
		this.printButton.addActionListener(new PrintListener());

		// your code here
		for (int i = 0; i < quantityFields.length; i++) {
			quantityFields[i].addFocusListener(new QuantityListener(menu.getItem(i)));
		}
	}

}