package cp213;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.math.BigDecimal;
import java.util.Map;

/**
 * Stores a HashMap of MenuItem objects and the quantity of each MenuItem
 * ordered. Each MenuItem may appear only once in the HashMap.
 *
 * @author Ashish Sharma
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2023-09-06
 */
public class Order implements Printable {

    /**
     * The current tax rate on menu items.
     */
    public static final BigDecimal TAX_RATE = new BigDecimal(0.13);

    // Attributes

    // your code here
    private Map<MenuItem, Integer> itemsMap;

    /**
     * Increments the quantity of a particular MenuItem in an Order with a new
     * quantity. If the MenuItem is not in the order, it is added.
     *
     * @param item     The MenuItem to purchase - the HashMap key.
     * @param quantity The number of the MenuItem to purchase - the HashMap value.
     */
	public void add(final MenuItem item, final int quantity) {

		// your code here
		if (quantity > 0) {
			itemsMap.put(item, itemsMap.getOrDefault(item, 0) + quantity);
		}

	}

    /**
     * Calculates the total value of all MenuItems and their quantities in the
     * HashMap.
     *
     * @return the total price for the MenuItems ordered.
     */
	public BigDecimal getSubTotal() {

		// your code here
		BigDecimal subTotal = BigDecimal.ZERO;

		for (Map.Entry<MenuItem, Integer> entry : itemsMap.entrySet()) {
			MenuItem item = entry.getKey();
			int quantity = entry.getValue();
			BigDecimal itemTotal = item.getPrice().multiply(BigDecimal.valueOf(quantity));
			subTotal = subTotal.add(itemTotal);
		}

		return subTotal;

	}

    /**
     * Calculates and returns the total taxes to apply to the subtotal of all
     * MenuItems in the order. Tax rate is TAX_RATE.
     *
     * @return total taxes on all MenuItems
     */
	public BigDecimal getTaxes() {

		// your code here
		BigDecimal subTotal = getSubTotal();
		return subTotal.multiply(TAX_RATE);

	}

    /**
     * Calculates and returns the total price of all MenuItems order, including tax.
     *
     * @return total price
     */
	public BigDecimal getTotal() {

		// your code here
		BigDecimal subTotal = getSubTotal();
		BigDecimal taxes = getTaxes();
		return subTotal.add(taxes);

	}

    /*
     * Implements the Printable interface print method. Prints lines to a Graphics2D
     * object using the drawString method. Prints the current contents of the Order.
     */
    @Override
    public int print(final Graphics graphics, final PageFormat pageFormat, final int pageIndex)
	    throws PrinterException {
	int result = PAGE_EXISTS;

	if (pageIndex == 0) {
	    final Graphics2D g2d = (Graphics2D) graphics;
	    g2d.setFont(new Font("MONOSPACED", Font.PLAIN, 12));
	    g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
	    // Now we perform our rendering
	    final String[] lines = this.toString().split("\n");
	    int y = 100;
	    final int inc = 12;

	    for (final String line : lines) {
		g2d.drawString(line, 100, y);
		y += inc;
	    }
	} else {
	    result = NO_SUCH_PAGE;
	}
	return result;
    }

    /**
     * Returns a String version of a receipt for all the MenuItems in the order.
     */
    @Override
	public String toString() {

		// your code here
    	StringBuilder itemReceipt = new StringBuilder();
    	
		for (Map.Entry<MenuItem, Integer> entry : itemsMap.entrySet()) {
			MenuItem item = entry.getKey();
			int itemQuantity = entry.getValue();
			BigDecimal itemTotal = item.getPrice().multiply(BigDecimal.valueOf(itemQuantity));

			itemReceipt.append(String.format("%-15s %d @ $%6.2f = $%7.2f%n", item.getName(), itemQuantity, item.getPrice(),
					itemTotal));
		}

		BigDecimal subTotal = getSubTotal();
		BigDecimal taxes = getTaxes();
		BigDecimal total = getTotal();

		itemReceipt.append("\nSubtotal:                   $").append(subTotal.setScale(2, BigDecimal.ROUND_HALF_UP))
				.append("\n");
		itemReceipt.append("Taxes:                      $").append(taxes.setScale(2, BigDecimal.ROUND_HALF_UP))
				.append("\n");
		itemReceipt.append("Total:                      $").append(total.setScale(2, BigDecimal.ROUND_HALF_UP))
				.append("\n");

		return itemReceipt.toString();

	}

    /**
     * Replaces the quantity of a particular MenuItem in an Order with a new
     * quantity. If the MenuItem is not in the order, it is added. If quantity is 0
     * or negative, the MenuItem is removed from the Order.
     *
     * @param item     The MenuItem to update
     * @param quantity The quantity to apply to item
     */
	public void update(final MenuItem item, final int quantity) {

		// your code here
		if (quantity > 0) {
			itemsMap.put(item, quantity);
		} else {
			itemsMap.remove(item);
		}

	}
}